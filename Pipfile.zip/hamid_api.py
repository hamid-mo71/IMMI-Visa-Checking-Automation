import asyncio
import os
import urllib

from aiohttp import web
from aiohttp import ClientSession, FormData
import aiohttp_jinja2
import jinja2
from bs4 import BeautifulSoup


async def login(username, password):
    """Get a login session with the provided username and password"""
    payload = {
        'username': username,
        'password': password,
        'wc_t': '',
        'wc_s': '',
        'login': 'x',
    }
    async with ClientSession() as session:
        url = 'https://online.immi.gov.au/lusc/login'

        async with session.get(url) as resp:
            html = await resp.text()
            soup = BeautifulSoup(html, 'html.parser')
            payload['wc_t'] = soup.find('input', attrs={'name':'wc_t'})['value']
            payload['wc_s'] = int(soup.find('input', attrs={'name':'wc_s'})['value'])
            payload = FormData(payload)

        async with session.post(url, data=payload) as resp:
            html = await resp.text()
            assert 'Login successful' in html

        async with session.get('https://online.immi.gov.au/usm/services') as resp:
            html = await resp.text()
            soup = BeautifulSoup(html, 'html.parser')
            # print(resp.status, html)
            payload = {
                'wc_t': soup.find('input', attrs={'name':'wc_t'})['value'],
                'wc_s': int(soup.find('input', attrs={'name':'wc_s'})['value']),
                'continue': 'x',
            }
            payload = FormData(payload)

        async with session.post(url, data=payload) as resp:

            html = await resp.text()
            return session.cookie_jar

async def fetch_immi_data(request):
    if request.method == 'POST':
        url = 'https://online.immi.gov.au/evo/thirdParty'
        data = await request.post()
        print(list(data.items()))
        payload = {
            # Name
            '_2a9a2a0a2c0b0': data['family_name'],
            # Given Name
            '_2a9a2a0a2c1b0': data['given_name'],
            # Document Type
            '_2a9a2a0a2e0a1a': '01',
            # Date of birth
            '_2a9a2a0a2g0a1a': data['date_of_birth'],
            # Date with dashes and numbers
            '_2a9a2a0a2g0a1a-date': data['dash_date_of_birth'],
            # Document Number
            '_2a9a2a0a2g0b1a': data['document_number'],
            # Country of Document
            '_2a9a2a0a2g0c1a': data['document_country'],
            # I Agree
            '_2a9a2a0a2i1b0': 'true',
            # Button
            '_2a9a2a0a3b0a': 'x',
            '_0a2-h': 'x',
            '_1-h': 'x',
            # Token Stuff
            'wc_t': '',
            'wc_s': '',
            # Stuff
            'cprofile_timings': 'interface_controls{time:4,result:1};html_start_load{time:295,result:1};unload_load{time:308,result:1};submit_load{time:5799,result:1};last_click_load_Submit{time:5807,result:1};',

        }

        async with ClientSession(cookie_jar=cookie) as session:
            post_data = {
                '_2a9a2a0a2c0b0': '',
                # Given Name
                '_2a9a2a0a2c1b0': '',
                # Document Type
                '_2a9a2a0a2e0a1a': '01',
                'wc_ajax': '_2a9a2a0a2e0a1a',
                '_0a2-h': 'x',
                '_1-h': 'x',

            }
            async with session.get(url) as resp:
                html = await resp.text()
                soup = BeautifulSoup(html, 'html.parser')
                post_data['wc_t'] = soup.find('input', attrs={'name':'wc_t'})['value']
                post_data['wc_s'] = int(soup.find('input', attrs={'name':'wc_s'})['value'])
                payload['wc_t'] = post_data['wc_t']
                payload['wc_s'] = post_data['wc_s']
                post_data = FormData(post_data)

            async with session.post(url, data=post_data) as resp:
                html = await resp.text()
                soup = BeautifulSoup(html, 'html.parser')
                payload = FormData(payload)
                

            async with session.post(url, data=payload) as resp:
                html = await resp.text()
                soup = BeautifulSoup(html, 'html.parser')
                # print(soup)
                assert 'Enquiry details' in html

            json_data = {
                'enquiry_details': {
                    'family_name': soup.find('div', id='_2a10a2a0a2b4a').div.text,
                    'given_names': soup.find('div', id='_2a10a2a0a2b4b').div.text,
                    'date_of_birth': soup.find('div', id='_2a10a2a0a2b4c').div.text,
                    'document_number': soup.find('div', id='_2a10a2a0a2b4d').div.text,
                    'country_of_document': soup.find('div', id='_2a10a2a0a2b4e').div.text,
                },
                'current_visa_details': {
                    'category_selected': soup.find('div', id='_2a10a2a0a2b8a').div.text,
                    'family_name': soup.find('div', id='_2a10a2a0a2b8b').div.text,
                    'given_name': soup.find('div', id='_2a10a2a0a2b8c').div.text,
                    'document_number': soup.find('div', id='_2a10a2a0a2b8f').div.text,
                    'visa_class_subclass': soup.find('div', id='_2a10a2a0a2b8g').div.text,
                    'education_sector': soup.find('div', id='_2a10a2a0a2b8i').div.text,
                    'visa_applicant': soup.find('div', id='_2a10a2a0a2b8j').div.text,
                    'visa_grant_date': soup.find('div', id='_2a10a2a0a2b8ba').div.text,
                    'visa_expiry_date': soup.find('div', id='_2a10a2a0a2b8bb').div.text,
                    'location': soup.find('div', id='_2a10a2a0a2b8bc').div.text,
                    'work_entitlements': soup.find('div', id='_2a10a2a0a2b10a').div.text,
                    'work_conditions': soup.find('div', id='_2a10a2a0a2b10d').div.text,
                }
            }

            return web.json_response(json_data)
    return web.Response(text='fine')
            

@aiohttp_jinja2.template('client.html')
async def hello(request):
    return {}


if __name__ == '__main__':

    loop = asyncio.get_event_loop()

    cookie = loop.run_until_complete(login('peter.christie@idvpacific.com', 'PKCAKMidvImmi77'))
    print(cookie)

    # loop.run_until_complete(fetch_immi_data())

    app = web.Application()
    app.add_routes([web.get('/', hello), web.route('*', '/immi-passport', fetch_immi_data)])
    aiohttp_jinja2.setup(app, loader=jinja2.FileSystemLoader(os.path.dirname(os.path.abspath(__file__))))
    runner = web.AppRunner(app)
    loop.run_until_complete(runner.setup())

    site = web.TCPSite(runner, 'localhost', 8080)
    loop.run_until_complete(site.start())

    loop.run_forever()